# static

## EOL-warning

**This package has been abandoned on 2016-12-13. Please use [gin-contrib/static](https://github.com/gin-contrib/static) instead.**

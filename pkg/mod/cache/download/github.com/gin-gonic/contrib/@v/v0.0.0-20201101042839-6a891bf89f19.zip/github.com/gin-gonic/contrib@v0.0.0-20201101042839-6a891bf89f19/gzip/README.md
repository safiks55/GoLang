# gzip

## EOL-warning

**This package has been abandoned on 2016-12-07. Please use [gin-contrib/gzip](https://github.com/gin-contrib/gzip) instead.**
